package com.example.lajusta.data.model

data class VisitaEdit(
    val id_visita: Int?,
    val fecha_visita: List<Int>?,
    val descripcion: String?,
    val id_tecnico: Int?,
    val id_quinta: Int?,
    val parcelas: List<Parcela>
)

