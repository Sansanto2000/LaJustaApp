package com.example.lajusta.data.model

data class Ronda(
    val id_ronda: Int?,
    val fecha_fin: List<Int>?,
    val fecha_inicio: List<Int>?
)
