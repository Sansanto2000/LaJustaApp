package com.example.lajusta.data.model

data class GoogleCustomSearchItem(
    val link: String?
)