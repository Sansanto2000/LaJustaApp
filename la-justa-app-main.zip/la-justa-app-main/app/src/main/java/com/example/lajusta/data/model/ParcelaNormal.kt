package com.example.lajusta.data.model

data class ParcelaNormal(
    val id_parcela: Int?,
    val cantidad_surcos: Int?,
    val cubierta: Boolean?,
    val cosecha: Boolean?,
    val id_verdura: Int?,
    val id_visita: Int?
)
