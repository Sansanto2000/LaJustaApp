package com.example.lajusta.data.model

data class User(
    val id_user: Int?,
    val nombre: String?,
    val apellido: String?,
    val direccion: String?,
    val username: String?,
    val password: String?,
    val email: String?,
    val roles: Int?,

)
