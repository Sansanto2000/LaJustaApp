package com.example.lajusta.data.model

data class Quinta(
    val id_quinta: Int?,
    val nombre: String?,
    val direccion: String?,
    val geoImg: String?,
    val fpId: Int?
)
