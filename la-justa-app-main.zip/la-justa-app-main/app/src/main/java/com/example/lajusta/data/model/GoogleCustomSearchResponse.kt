package com.example.lajusta.data.model

data class GoogleCustomSearchResponse(
    val items: List<GoogleCustomSearchItem>?
)

