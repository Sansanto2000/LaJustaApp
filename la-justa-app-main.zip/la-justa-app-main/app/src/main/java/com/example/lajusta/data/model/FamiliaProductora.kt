package com.example.lajusta.data.model

data class FamiliaProductora(
    val id_fp: Int?,
    val nombre: String?,
    val fecha_afiliacion: List<Int>?
)
