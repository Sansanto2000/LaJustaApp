package com.example.lajusta.data.remote;

public class ApiUtils {

    public static final String BASE_URL = "http://10.0.2.2:80/api/";
    //public static final String BASE_URL = "http://192.168.1.39:80/api/";
    //public static final String BASE_URL = "http://ip172-18-0-95-cfpqn760qau000flp54g-80.direct.labs.play-with-docker.com/";
}
